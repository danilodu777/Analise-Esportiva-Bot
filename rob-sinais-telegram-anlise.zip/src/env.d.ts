/// <reference types="vite/client" />

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

interface ImportMetaEnv {
  readonly VITE_FOOTBALL_API_KEY: string;
  readonly VITE_FOOTBALL_DATA_KEY: string;
  readonly VITE_SOCCER_ODDS_KEY: string;
  // Adicione outras variáveis de ambiente aqui...
}