import { useState, useEffect } from 'react';
import { mockMatches } from '../data/mockData';
import { Match } from '../types';
import { 
  Activity, 
  Filter,
  TrendingUp,
  Target,
  CornerDownRight,
  Zap
} from 'lucide-react';

export function MatchesPage() {
  const [matches, setMatches] = useState<Match[]>(mockMatches);
  const [filter, setFilter] = useState<'all' | 'live' | 'halftime' | 'finished'>('all');
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setMatches(prev => prev.map(match => {
        if (match.status === 'live' && match.minute < 90) {
          return {
            ...match,
            minute: match.minute + 1,
            stats: {
              ...match.stats,
              homeAttacks: match.stats.homeAttacks + Math.floor(Math.random() * 2),
              awayAttacks: match.stats.awayAttacks + Math.floor(Math.random() * 2),
              homeDangerousAttacks: match.stats.homeDangerousAttacks + (Math.random() > 0.7 ? 1 : 0),
              awayDangerousAttacks: match.stats.awayDangerousAttacks + (Math.random() > 0.7 ? 1 : 0),
            }
          };
        }
        return match;
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const filteredMatches = matches.filter(m => 
    filter === 'all' ? true : m.status === filter
  );

  const calculateProbability = (value: number, max: number) => {
    return Math.min(Math.round((value / max) * 100), 99);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <Activity className="h-8 w-8 text-green-400" />
              Jogos ao Vivo
            </h1>
            <p className="text-gray-400 mt-1">
              Acompanhe estatísticas em tempo real de jogos ao redor do mundo
            </p>
          </div>
          
          {/* Filters */}
          <div className="flex items-center gap-2 bg-gray-800 rounded-lg p-1">
            <button
              onClick={() => setFilter('all')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                filter === 'all' ? 'bg-green-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Todos
            </button>
            <button
              onClick={() => setFilter('live')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${
                filter === 'live' ? 'bg-green-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
              Ao Vivo
            </button>
            <button
              onClick={() => setFilter('halftime')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                filter === 'halftime' ? 'bg-green-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Intervalo
            </button>
            <button
              onClick={() => setFilter('finished')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                filter === 'finished' ? 'bg-green-600 text-white' : 'text-gray-400 hover:text-white'
              }`}
            >
              Finalizados
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Matches List */}
          <div className="lg:col-span-1 space-y-4">
            {filteredMatches.map((match) => (
              <div
                key={match.id}
                onClick={() => setSelectedMatch(match)}
                className={`bg-gray-800/50 backdrop-blur-sm rounded-xl p-4 border cursor-pointer transition-all ${
                  selectedMatch?.id === match.id 
                    ? 'border-green-500 ring-1 ring-green-500' 
                    : 'border-gray-700 hover:border-gray-600'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs text-gray-500">{match.league}</span>
                  <span className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full ${
                    match.status === 'live' 
                      ? 'bg-red-500/20 text-red-400' 
                      : match.status === 'halftime'
                      ? 'bg-yellow-500/20 text-yellow-400'
                      : 'bg-gray-500/20 text-gray-400'
                  }`}>
                    {match.status === 'live' && (
                      <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
                    )}
                    {match.status === 'live' ? `${match.minute}'` : 
                     match.status === 'halftime' ? 'Intervalo' : 'Finalizado'}
                  </span>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{match.homeTeam}</span>
                    <span className="text-2xl font-bold">{match.homeScore}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{match.awayTeam}</span>
                    <span className="text-2xl font-bold">{match.awayScore}</span>
                  </div>
                </div>

                {/* Quick Stats */}
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-700">
                  <div className="flex items-center gap-1 text-sm text-gray-400">
                    <CornerDownRight className="h-4 w-4" />
                    <span>{match.stats.homeCorners} - {match.stats.awayCorners}</span>
                  </div>
                  <div className="flex items-center gap-1 text-sm text-gray-400">
                    <Target className="h-4 w-4" />
                    <span>{match.stats.homeShots} - {match.stats.awayShots}</span>
                  </div>
                  <div className="flex items-center gap-1 text-sm text-gray-400">
                    <Zap className="h-4 w-4" />
                    <span>{match.stats.homeDangerousAttacks} - {match.stats.awayDangerousAttacks}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Match Details */}
          <div className="lg:col-span-2">
            {selectedMatch ? (
              <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl border border-gray-700 overflow-hidden">
                {/* Match Header */}
                <div className="bg-gradient-to-r from-green-900/50 to-emerald-900/50 p-6 border-b border-gray-700">
                  <div className="text-center">
                    <span className="text-sm text-gray-400">{selectedMatch.league}</span>
                    <div className="flex items-center justify-center gap-8 mt-4">
                      <div className="text-center">
                        <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center text-2xl font-bold mb-2">
                          {selectedMatch.homeTeam.charAt(0)}
                        </div>
                        <p className="font-medium">{selectedMatch.homeTeam}</p>
                      </div>
                      <div className="text-center">
                        <div className="text-4xl font-bold">
                          {selectedMatch.homeScore} - {selectedMatch.awayScore}
                        </div>
                        <div className={`mt-2 text-sm ${
                          selectedMatch.status === 'live' ? 'text-red-400' : 'text-gray-400'
                        }`}>
                          {selectedMatch.status === 'live' ? `${selectedMatch.minute}'` : 
                           selectedMatch.status === 'halftime' ? 'Intervalo' : 'Finalizado'}
                        </div>
                      </div>
                      <div className="text-center">
                        <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center text-2xl font-bold mb-2">
                          {selectedMatch.awayTeam.charAt(0)}
                        </div>
                        <p className="font-medium">{selectedMatch.awayTeam}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Statistics */}
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-green-400" />
                    Estatísticas & Probabilidades
                  </h3>

                  <div className="space-y-6">
                    {/* Possession */}
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>{selectedMatch.stats.homePossession}%</span>
                        <span className="text-gray-400">Posse de Bola</span>
                        <span>{selectedMatch.stats.awayPossession}%</span>
                      </div>
                      <div className="flex h-2 rounded-full overflow-hidden bg-gray-700">
                        <div 
                          className="bg-green-500 transition-all duration-500"
                          style={{ width: `${selectedMatch.stats.homePossession}%` }}
                        ></div>
                        <div 
                          className="bg-blue-500 transition-all duration-500"
                          style={{ width: `${selectedMatch.stats.awayPossession}%` }}
                        ></div>
                      </div>
                    </div>

                    {/* Corners */}
                    <div className="bg-gray-700/30 rounded-lg p-4">
                      <div className="flex justify-between items-center mb-3">
                        <span className="text-2xl font-bold">{selectedMatch.stats.homeCorners}</span>
                        <div className="text-center">
                          <CornerDownRight className="h-5 w-5 text-blue-400 mx-auto mb-1" />
                          <span className="text-sm text-gray-400">Escanteios</span>
                        </div>
                        <span className="text-2xl font-bold">{selectedMatch.stats.awayCorners}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-green-400">
                          Prob. próximo: {calculateProbability(selectedMatch.stats.homeDangerousAttacks, 60)}%
                        </span>
                        <span className="text-blue-400">
                          Prob. próximo: {calculateProbability(selectedMatch.stats.awayDangerousAttacks, 60)}%
                        </span>
                      </div>
                    </div>

                    {/* Shots */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-gray-700/30 rounded-lg p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-gray-400 text-sm">Chutes</p>
                            <p className="text-xl font-bold">{selectedMatch.stats.homeShots} - {selectedMatch.stats.awayShots}</p>
                          </div>
                          <Target className="h-8 w-8 text-yellow-400" />
                        </div>
                        <p className="text-sm text-yellow-400 mt-2">
                          Prob. gol: {calculateProbability(selectedMatch.stats.homeShotsOnTarget + selectedMatch.stats.awayShotsOnTarget, 15)}%
                        </p>
                      </div>
                      <div className="bg-gray-700/30 rounded-lg p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <p className="text-gray-400 text-sm">Chutes no Gol</p>
                            <p className="text-xl font-bold">{selectedMatch.stats.homeShotsOnTarget} - {selectedMatch.stats.awayShotsOnTarget}</p>
                          </div>
                          <Target className="h-8 w-8 text-green-400" />
                        </div>
                        <p className="text-sm text-green-400 mt-2">
                          Precisão: {Math.round((selectedMatch.stats.homeShotsOnTarget + selectedMatch.stats.awayShotsOnTarget) / (selectedMatch.stats.homeShots + selectedMatch.stats.awayShots) * 100)}%
                        </p>
                      </div>
                    </div>

                    {/* Pressure Analysis */}
                    <div className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 rounded-lg p-4 border border-purple-500/30">
                      <h4 className="text-sm font-medium text-purple-400 mb-3 flex items-center gap-2">
                        <Zap className="h-4 w-4" />
                        Análise de Pressão
                      </h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <p className="text-gray-400 text-xs mb-1">Ataques Perigosos</p>
                          <div className="flex items-center gap-2">
                            <span className="text-xl font-bold">{selectedMatch.stats.homeDangerousAttacks}</span>
                            <div className="flex-1 h-2 bg-gray-700 rounded-full">
                              <div 
                                className="h-full bg-purple-500 rounded-full transition-all duration-500"
                                style={{ width: `${calculateProbability(selectedMatch.stats.homeDangerousAttacks, 70)}%` }}
                              ></div>
                            </div>
                            <span className="text-xl font-bold">{selectedMatch.stats.awayDangerousAttacks}</span>
                          </div>
                        </div>
                        <div>
                          <p className="text-gray-400 text-xs mb-1">Total de Ataques</p>
                          <div className="flex items-center gap-2">
                            <span className="text-xl font-bold">{selectedMatch.stats.homeAttacks}</span>
                            <div className="flex-1 h-2 bg-gray-700 rounded-full">
                              <div 
                                className="h-full bg-pink-500 rounded-full transition-all duration-500"
                                style={{ width: `${calculateProbability(selectedMatch.stats.homeAttacks, 100)}%` }}
                              ></div>
                            </div>
                            <span className="text-xl font-bold">{selectedMatch.stats.awayAttacks}</span>
                          </div>
                        </div>
                      </div>
                      <div className="mt-4 pt-4 border-t border-purple-500/30">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-300">
                            {selectedMatch.homeTeam}: {' '}
                            <span className={`font-medium ${
                              selectedMatch.stats.homeDangerousAttacks > 40 ? 'text-red-400' :
                              selectedMatch.stats.homeDangerousAttacks > 25 ? 'text-yellow-400' :
                              'text-green-400'
                            }`}>
                              Pressão {selectedMatch.stats.homeDangerousAttacks > 40 ? 'Alta' :
                                       selectedMatch.stats.homeDangerousAttacks > 25 ? 'Média' : 'Baixa'}
                            </span>
                          </span>
                          <span className="text-gray-300">
                            {selectedMatch.awayTeam}: {' '}
                            <span className={`font-medium ${
                              selectedMatch.stats.awayDangerousAttacks > 40 ? 'text-red-400' :
                              selectedMatch.stats.awayDangerousAttacks > 25 ? 'text-yellow-400' :
                              'text-green-400'
                            }`}>
                              Pressão {selectedMatch.stats.awayDangerousAttacks > 40 ? 'Alta' :
                                       selectedMatch.stats.awayDangerousAttacks > 25 ? 'Média' : 'Baixa'}
                            </span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-gray-800/50 backdrop-blur-sm rounded-xl border border-gray-700 p-12 text-center">
                <Filter className="h-16 w-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-medium text-gray-400 mb-2">
                  Selecione um jogo
                </h3>
                <p className="text-gray-500">
                  Clique em um jogo para ver estatísticas detalhadas e probabilidades
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
