import axios from 'axios';

// Configuração da API
const API_CONFIG = {
  FOOTBALL_API: {
    BASE_URL: 'https://v3.football.api-sports.io',
    API_KEY: import.meta.env.VITE_FOOTBALL_API_KEY || '',
    HEADERS: {
      'x-apisports-key': import.meta.env.VITE_FOOTBALL_API_KEY || '',
      'x-rapidapi-host': 'v3.football.api-sports.io'
    }
  },
  FOOTBALL_DATA: {
    BASE_URL: 'https://api.football-data.org/v4',
    API_KEY: import.meta.env.VITE_FOOTBALL_DATA_KEY || ''
  },
  SOCCER_ODDS: {
    BASE_URL: 'https://api.soccer-odds.com/v1',
    API_KEY: import.meta.env.VITE_SOCCER_ODDS_KEY || ''
  }
};

// Cliente HTTP
const httpClient = axios.create({
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Interceptor para adicionar chaves de API
httpClient.interceptors.request.use((config) => {
  // Aqui você pode adicionar lógica para diferentes APIs
  if (config.url?.includes('api-football')) {
    config.headers['x-apisports-key'] = API_CONFIG.FOOTBALL_API.API_KEY;
    config.headers['x-rapidapi-host'] = 'v3.football.api-sports.io';
  }
  
  if (config.url?.includes('football-data')) {
    config.headers['X-Auth-Token'] = API_CONFIG.FOOTBALL_DATA.API_KEY;
  }
  
  return config;
});

// Interfaces para dados de API
export interface ApiMatch {
  id: number;
  league: {
    id: number;
    name: string;
    country: string;
    logo: string;
  };
  teams: {
    home: ApiTeam;
    away: ApiTeam;
  };
  goals: {
    home: number;
    away: number;
  };
  fixture: {
    id: number;
    referee: string | null;
    timezone: string;
    date: string;
    timestamp: number;
    periods: {
      first: number | null;
      second: number | null;
    };
    venue: {
      id: number | null;
      name: string;
      city: string;
    };
    status: {
      long: string;
      short: string;
      elapsed: number | null;
    };
  };
  statistics: ApiMatchStatistics[];
  events: ApiMatchEvent[];
}

export interface ApiTeam {
  id: number;
  name: string;
  logo: string;
  winner: boolean | null;
}

export interface ApiMatchStatistics {
  team: ApiTeam;
  statistics: Array<{
    type: string;
    value: number | string;
  }>;
}

export interface ApiMatchEvent {
  time: {
    elapsed: number;
    extra: number | null;
  };
  team: ApiTeam;
  player: {
    id: number;
    name: string;
  };
  assist: {
    id: number | null;
    name: string | null;
  };
  type: 'Goal' | 'Card' | 'subst' | 'Var';
  detail: string;
  comments: string | null;
}

export interface ApiLiveMatch {
  fixture: {
    id: number;
    referee: string | null;
    timezone: string;
    date: string;
    timestamp: number;
  };
  league: {
    id: number;
    name: string;
    country: string;
    logo: string;
    flag: string;
    season: number;
    round: string;
  };
  teams: {
    home: ApiTeam;
    away: ApiTeam;
  };
  goals: {
    home: number;
    away: number;
  };
  score: {
    halftime: {
      home: number;
      away: number;
    };
    fulltime: {
      home: number;
      away: number;
    };
    extratime: {
      home: number | null;
      away: number | null;
    };
    penalty: {
      home: number | null;
      away: number | null;
    };
  };
  events: ApiMatchEvent[];
  statistics: ApiMatchStatistics[];
  lineups: any[];
}

export interface ApiOdds {
  fixture: {
    id: number;
    timezone: string;
    date: string;
    timestamp: number;
  };
  league: {
    id: number;
    name: string;
    country: string;
    logo: string;
    flag: string;
    season: number;
  };
  teams: {
    home: ApiTeam;
    away: ApiTeam;
  };
  bookmakers: Array<{
    id: number;
    name: string;
    bets: Array<{
      id: number;
      name: string;
      values: Array<{
        value: string;
        odd: string;
      }>;
    }>;
  }>;
}

// Serviços de API
export const FootballApiService = {
  // Buscar jogos ao vivo (simulado - normalmente seria da API real)
  async getLiveMatches(): Promise<ApiLiveMatch[]> {
    try {
      // Em produção, descomente este código:
      // const response = await httpClient.get(
      //   `${API_CONFIG.FOOTBALL_API.BASE_URL}/fixtures?live=all`,
      //   { headers: API_CONFIG.FOOTBALL_API.HEADERS }
      // );
      // return response.data.response;
      
      // Simulação com dados mockados enquanto não há chave de API
      return await simulateLiveMatches();
    } catch (error) {
      console.error('Error fetching live matches:', error);
      return [];
    }
  },

  // Buscar estatísticas de um jogo específico
  async getMatchStatistics(_fixtureId: number): Promise<ApiMatchStatistics[]> {
    try {
      // Em produção:
      // const response = await httpClient.get(
      //   `${API_CONFIG.FOOTBALL_API.BASE_URL}/fixtures/statistics?fixture=${fixtureId}`,
      //   { headers: API_CONFIG.FOOTBALL_API.HEADERS }
      // );
      // return response.data.response;
      
      return await simulateMatchStatistics();
    } catch (error) {
      console.error('Error fetching match statistics:', error);
      return [];
    }
  },

  // Buscar eventos do jogo (gols, cartões, substituições)
  async getMatchEvents(_fixtureId: number): Promise<ApiMatchEvent[]> {
    try {
      // Em produção:
      // const response = await httpClient.get(
      //   `${API_CONFIG.FOOTBALL_API.BASE_URL}/fixtures/events?fixture=${fixtureId}`,
      //   { headers: API_CONFIG.FOOTBALL_API.HEADERS }
      // );
      // return response.data.response;
      
      return await simulateMatchEvents();
    } catch (error) {
      console.error('Error fetching match events:', error);
      return [];
    }
  },

  // Buscar odds (probabilidades) de um jogo
  async getMatchOdds(_fixtureId: number): Promise<ApiOdds | null> {
    try {
      // Em produção:
      // const response = await httpClient.get(
      //   `${API_CONFIG.FOOTBALL_API.BASE_URL}/odds?fixture=${fixtureId}&bookmaker=1`,
      //   { headers: API_CONFIG.FOOTBALL_API.HEADERS }
      // );
      // return response.data.response[0] || null;
      
      return await simulateMatchOdds();
    } catch (error) {
      console.error('Error fetching match odds:', error);
      return null;
    }
  },

  // Buscar jogos por liga e data
  async getMatchesByDate(_date: string, _leagueId?: number): Promise<ApiMatch[]> {
    try {
      // Em produção:
      // let url = `${API_CONFIG.FOOTBALL_API.BASE_URL}/fixtures?date=${date}`;
      // if (leagueId) url += `&league=${leagueId}`;
      // const response = await httpClient.get(url, { headers: API_CONFIG.FOOTBALL_API.HEADERS });
      // return response.data.response;
      
      return await simulateMatchesByDate();
    } catch (error) {
      console.error('Error fetching matches by date:', error);
      return [];
    }
  },

  // Buscar estatísticas de pressão do jogo (análise personalizada)
  async getPressureAnalysis(fixtureId: number): Promise<{
    homePressure: number;
    awayPressure: number;
    dangerousAttacks: {
      home: number;
      away: number;
    };
    ballPossession: {
      home: number;
      away: number;
    };
    pressureLevel: 'low' | 'medium' | 'high';
  }> {
    try {
      // Esta é uma análise personalizada baseada em múltiplas estatísticas
      const stats = await this.getMatchStatistics(fixtureId);
      
      // Calcular pressão baseada em estatísticas
      return calculatePressureAnalysis(stats);
    } catch (error) {
      console.error('Error calculating pressure analysis:', error);
      return {
        homePressure: 50,
        awayPressure: 50,
        dangerousAttacks: { home: 0, away: 0 },
        ballPossession: { home: 50, away: 50 },
        pressureLevel: 'medium'
      };
    }
  }
};

// Funções de simulação (para desenvolvimento)
async function simulateLiveMatches(): Promise<ApiLiveMatch[]> {
  const leagues = [
    { id: 39, name: 'Premier League', country: 'England', logo: 'https://media.api-sports.io/football/leagues/39.png' },
    { id: 140, name: 'La Liga', country: 'Spain', logo: 'https://media.api-sports.io/football/leagues/140.png' },
    { id: 71, name: 'Série A', country: 'Brazil', logo: 'https://media.api-sports.io/football/leagues/71.png' },
    { id: 78, name: 'Bundesliga', country: 'Germany', logo: 'https://media.api-sports.io/football/leagues/78.png' },
    { id: 135, name: 'Serie A', country: 'Italy', logo: 'https://media.api-sports.io/football/leagues/135.png' },
  ];

  const teams = [
    { id: 50, name: 'Manchester City', logo: 'https://media.api-sports.io/football/teams/50.png' },
    { id: 40, name: 'Liverpool', logo: 'https://media.api-sports.io/football/teams/40.png' },
    { id: 541, name: 'Real Madrid', logo: 'https://media.api-sports.io/football/teams/541.png' },
    { id: 529, name: 'Barcelona', logo: 'https://media.api-sports.io/football/teams/529.png' },
    { id: 127, name: 'Flamengo', logo: 'https://media.api-sports.io/football/teams/127.png' },
    { id: 119, name: 'Palmeiras', logo: 'https://media.api-sports.io/football/teams/119.png' },
    { id: 157, name: 'Bayern Munich', logo: 'https://media.api-sports.io/football/teams/157.png' },
    { id: 165, name: 'Dortmund', logo: 'https://media.api-sports.io/football/teams/165.png' },
    { id: 496, name: 'Juventus', logo: 'https://media.api-sports.io/football/teams/496.png' },
    { id: 505, name: 'Inter Milan', logo: 'https://media.api-sports.io/football/teams/505.png' },
  ];

  const matches: ApiLiveMatch[] = [];

  // Criar 6 jogos simulados
  for (let i = 0; i < 6; i++) {
    const league = leagues[i % leagues.length];
    const homeTeam = teams[i * 2 % teams.length];
    const awayTeam = teams[(i * 2 + 1) % teams.length];
    // Not used in simulation but kept for reference: const minute = [23, 45, 67, 82, 55, 90][i];
    const homeScore = [2, 1, 0, 3, 1, 4][i];
    const awayScore = [1, 1, 0, 2, 2, 0][i];
    
    matches.push({
      fixture: {
        id: 1000 + i,
        referee: 'M. Oliver',
        timezone: 'UTC',
        date: new Date().toISOString(),
        timestamp: Math.floor(Date.now() / 1000)
      },
      league: {
        ...league,
        flag: `https://media.api-sports.io/flags/${league.country.toLowerCase()}.svg`,
        season: 2024,
        round: 'Regular Season - 20'
      },
      teams: {
        home: { ...homeTeam, winner: homeScore > awayScore ? true : homeScore === awayScore ? null : false },
        away: { ...awayTeam, winner: awayScore > homeScore ? true : homeScore === awayScore ? null : false }
      },
      goals: { home: homeScore, away: awayScore },
      score: {
        halftime: { home: Math.floor(homeScore / 2), away: Math.floor(awayScore / 2) },
        fulltime: { home: homeScore, away: awayScore },
        extratime: { home: null, away: null },
        penalty: { home: null, away: null }
      },
      events: [],
      statistics: [],
      lineups: []
    });
  }

  return matches;
}

async function simulateMatchStatistics(): Promise<ApiMatchStatistics[]> {
  const randomStats = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;
  
  return [
    {
      team: { id: 50, name: 'Home Team', logo: '', winner: null },
      statistics: [
        { type: 'Shots on Goal', value: randomStats(5, 15) },
        { type: 'Shots off Goal', value: randomStats(3, 10) },
        { type: 'Total Shots', value: randomStats(10, 25) },
        { type: 'Blocked Shots', value: randomStats(1, 5) },
        { type: 'Shots insidebox', value: randomStats(5, 15) },
        { type: 'Shots outsidebox', value: randomStats(2, 8) },
        { type: 'Fouls', value: randomStats(5, 20) },
        { type: 'Corner Kicks', value: randomStats(2, 12) },
        { type: 'Offsides', value: randomStats(0, 5) },
        { type: 'Ball Possession', value: `${randomStats(40, 65)}%` },
        { type: 'Yellow Cards', value: randomStats(0, 4) },
        { type: 'Red Cards', value: randomStats(0, 1) },
        { type: 'Goalkeeper Saves', value: randomStats(0, 8) },
        { type: 'Total passes', value: randomStats(300, 700) },
        { type: 'Passes accurate', value: randomStats(200, 600) },
        { type: 'Passes %', value: `${randomStats(70, 90)}%` },
        { type: 'expected_goals', value: (Math.random() * 3).toFixed(2) },
      ]
    },
    {
      team: { id: 40, name: 'Away Team', logo: '', winner: null },
      statistics: [
        { type: 'Shots on Goal', value: randomStats(4, 14) },
        { type: 'Shots off Goal', value: randomStats(2, 9) },
        { type: 'Total Shots', value: randomStats(8, 22) },
        { type: 'Blocked Shots', value: randomStats(1, 4) },
        { type: 'Shots insidebox', value: randomStats(4, 13) },
        { type: 'Shots outsidebox', value: randomStats(1, 7) },
        { type: 'Fouls', value: randomStats(6, 18) },
        { type: 'Corner Kicks', value: randomStats(1, 10) },
        { type: 'Offsides', value: randomStats(0, 4) },
        { type: 'Ball Possession', value: `${randomStats(35, 60)}%` },
        { type: 'Yellow Cards', value: randomStats(0, 3) },
        { type: 'Red Cards', value: randomStats(0, 1) },
        { type: 'Goalkeeper Saves', value: randomStats(0, 7) },
        { type: 'Total passes', value: randomStats(280, 650) },
        { type: 'Passes accurate', value: randomStats(180, 550) },
        { type: 'Passes %', value: `${randomStats(65, 88)}%` },
        { type: 'expected_goals', value: (Math.random() * 2.5).toFixed(2) },
      ]
    }
  ];
}

async function simulateMatchEvents(): Promise<ApiMatchEvent[]> {
  return [
    {
      time: { elapsed: 23, extra: null },
      team: { id: 50, name: 'Home Team', logo: '', winner: null },
      player: { id: 1001, name: 'J. Player' },
      assist: { id: null, name: null },
      type: 'Goal',
      detail: 'Normal Goal',
      comments: null
    },
    {
      time: { elapsed: 45, extra: 1 },
      team: { id: 40, name: 'Away Team', logo: '', winner: null },
      player: { id: 1002, name: 'A. Striker' },
      assist: { id: 1003, name: 'M. Assistant' },
      type: 'Goal',
      detail: 'Normal Goal',
      comments: null
    },
    {
      time: { elapsed: 67, extra: null },
      team: { id: 50, name: 'Home Team', logo: '', winner: null },
      player: { id: 1004, name: 'D. Defender' },
      assist: { id: null, name: null },
      type: 'Card',
      detail: 'Yellow Card',
      comments: 'Foul'
    }
  ];
}

async function simulateMatchOdds(): Promise<ApiOdds> {
  return {
    fixture: {
      id: 1000,
      timezone: 'UTC',
      date: new Date().toISOString(),
      timestamp: Math.floor(Date.now() / 1000)
    },
    league: {
      id: 39,
      name: 'Premier League',
      country: 'England',
      logo: 'https://media.api-sports.io/football/leagues/39.png',
      flag: 'https://media.api-sports.io/flags/gb.svg',
      season: 2024
    },
    teams: {
      home: { id: 50, name: 'Home Team', logo: '', winner: null },
      away: { id: 40, name: 'Away Team', logo: '', winner: null }
    },
    bookmakers: [
      {
        id: 1,
        name: 'Bet365',
        bets: [
          {
            id: 1,
            name: 'Match Winner',
            values: [
              { value: 'Home', odd: '1.85' },
              { value: 'Draw', odd: '3.40' },
              { value: 'Away', odd: '4.20' }
            ]
          },
          {
            id: 5,
            name: 'Over/Under',
            values: [
              { value: 'Over 2.5', odd: '1.80' },
              { value: 'Under 2.5', odd: '1.95' }
            ]
          },
          {
            id: 8,
            name: 'Both Teams Score',
            values: [
              { value: 'Yes', odd: '1.65' },
              { value: 'No', odd: '2.10' }
            ]
          }
        ]
      }
    ]
  };
}

async function simulateMatchesByDate(): Promise<ApiMatch[]> {
  return [];
}

function calculatePressureAnalysis(
  stats: ApiMatchStatistics[]
): {
  homePressure: number;
  awayPressure: number;
  dangerousAttacks: { home: number; away: number };
  ballPossession: { home: number; away: number };
  pressureLevel: 'low' | 'medium' | 'high';
} {
  // Análise simplificada para demonstração
  const homeStats = stats[0]?.statistics || [];
  const awayStats = stats[1]?.statistics || [];
  
  // Extrair valores
  const getStatValue = (statsArray: any[], statName: string): number => {
    const stat = statsArray.find(s => s.type === statName);
    if (!stat) return 0;
    if (typeof stat.value === 'string' && stat.value.includes('%')) {
      return parseInt(stat.value.replace('%', ''));
    }
    return Number(stat.value) || 0;
  };
  
  const homeShots = getStatValue(homeStats, 'Total Shots');
  const awayShots = getStatValue(awayStats, 'Total Shots');
  const homePossession = getStatValue(homeStats, 'Ball Possession');
  const awayPossession = getStatValue(awayStats, 'Ball Possession');
  const homeCorners = getStatValue(homeStats, 'Corner Kicks');
  const awayCorners = getStatValue(awayStats, 'Corner Kicks');
  
  // Calcular pressão (algoritmo simplificado)
  const homePressure = Math.min(
    100,
    Math.round(
      (homeShots * 0.4) +
      (homeCorners * 0.3) +
      (homePossession * 0.3)
    )
  );
  
  const awayPressure = Math.min(
    100,
    Math.round(
      (awayShots * 0.4) +
      (awayCorners * 0.3) +
      (awayPossession * 0.3)
    )
  );
  
  // Normalizar para soma 100%
  const totalPressure = homePressure + awayPressure;
  const normalizedHomePressure = Math.round((homePressure / totalPressure) * 100);
  const normalizedAwayPressure = Math.round((awayPressure / totalPressure) * 100);
  
  // Determinar nível de pressão
  const maxPressure = Math.max(normalizedHomePressure, normalizedAwayPressure);
  const pressureLevel = maxPressure > 70 ? 'high' : maxPressure > 55 ? 'medium' : 'low';
  
  return {
    homePressure: normalizedHomePressure,
    awayPressure: normalizedAwayPressure,
    dangerousAttacks: {
      home: Math.round(homeShots * 0.6),
      away: Math.round(awayShots * 0.6)
    },
    ballPossession: {
      home: homePossession,
      away: awayPossession
    },
    pressureLevel
  };
}

export default FootballApiService;